<?php
// This file was auto-generated from sdk-root/src/data/s3/2006-03-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListBuckets', 'input' => [], 'errorExpectedFromService' => false, ], ],];
