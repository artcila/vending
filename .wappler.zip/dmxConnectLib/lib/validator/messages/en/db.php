<?php

namespace lib\validator\messages\en;

class db extends \lib\core\Singleton
{
    public $exists = "Value does not exist in database.";
    public $notexists = "Value already exists in database.";
}
