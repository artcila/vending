<?php

namespace lib\validator\messages\en;

class unicode extends \lib\core\Singleton
{
    public $unicodelettersonly = "Entered characters are not allowed.";
    public $unicodescript = "Entered characters are not allowed.";
}
